import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

public class servletforgame4 extends HttpServlet
{

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");

 }

 
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        Connection con1=null;
        Statement stmt= null;
        ResultSet rs3= null;
        
        try
        {
          
            Class.forName("com.mysql.cj.jdbc.Driver");
             
            
            con1= DriverManager.getConnection("jdbc:mysql://localhost:3306/snakeandladder","root","root");
            
         
             stmt = con1.createStatement();
         
         rs3=stmt.executeQuery("select * from temptablea where Name='b'");
         while(rs3.next())
            {
                
                String json = new String("{ \"name\" : \"Bhaalu\" }");
                out.print(json);
                
                //String uname=rs3.getString("Name");
                //String ulocation=rs3.getString("Location");
                //String uisplayed=rs3.getString("Isplayed");
                //String ucolor=rs3.getString("Color");
                
                //out.println("Details of opponent player");
                //out.println("Name of player :   "+ uname);
                //out.println("Location       :   "+ ulocation);
                //out.println("Played or not? :   "+ uisplayed);
                //out.println("Color          :   "+ ucolor);
            }
        
        }
        catch(Exception e)
        {
            out.println("Sorry!! Something went wrong");
            out.println(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

    private ResultSet executeQuery() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
