/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

/**
 *
 * @author Rushabh
 */
public class playajax extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try
        {
            Cookie ck_array[] = request.getCookies();
            String Requester_Username = new String();
            for( Cookie ck : ck_array)
            {
                if(ck.getName().equals("UserName"))
                {
                   if(ck.getValue() != null && ck.getValue() != "")
                   {
                       Requester_Username = ck.getValue();
                   }
                }
            }
            
            int Requester_Location = Integer.parseInt(request.getParameter("location"));
            String Requester_IsPlayed = request.getParameter("isplayed");
            String Requester_Color = request.getParameter("color");
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snakeandladder","root","root");
            Statement stmt = con.createStatement();
            
            //Putting this Values into DB
            String sql = "UPDATE temptablea SET Location="+Requester_Location+", Color=\"" + 
                    Requester_Color + "\" WHERE `Name`=\""+Requester_Username+"\"";
            stmt.executeUpdate(sql);
            
            //Fetching from DB and Sending as a response
            response.setContentType("application/json");
            sql = "SELECT * FROM temptablea";
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next())
            {
                String Opponent_Username = rs.getString(1);
                if(Opponent_Username.equals(Requester_Username))
                    continue;
                
                if(Requester_IsPlayed.equals("true")) {
                    stmt.executeUpdate("UPDATE temptablea SET CanPlay=\"false\" WHERE `Name`=\""+Requester_Username+"\"");
                    stmt.executeUpdate("UPDATE temptablea SET CanPlay=\"true\" WHERE `Name`=\""+Opponent_Username+"\"");
                }
                
                int Opponent_Location = rs.getInt(2);
                String Opponent_CanPlay = rs.getString(3);
                String Opponent_Color = rs.getString(4);
                
                String json = "{ \"name\" : \"" + Opponent_Username + "\", " + 
                                "\"location\" : " + Opponent_Location + ", " + 
                                "\"canplay\" : " + Opponent_CanPlay + ", " + 
                                "\"color\" : \"" + Opponent_Color + "\" }";
                rs.close();
                PrintWriter out = response.getWriter();
                out.print(json);
            }
            
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
