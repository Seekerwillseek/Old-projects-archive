

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class servletforgame3 extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        Connection con = null;
        ResultSet rs = null;
        Statement stmt = null;
        String pn=request.getParameter("playername");
        String pl=request.getParameter("mylocation");
        String ip=request.getParameter("isAplayed");
        String pc=request.getParameter("mycolor");
    
        try
        {
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            con= DriverManager.getConnection("jdbc:mysql://localhost:3306/snakeandladder","root","root");
         
          PreparedStatement pst=con.prepareStatement("update temptablea set Location=?, Isplayed=?, Color=? where Name='"+pn+"' ");
         pst.setString(1, pl);
         pst.setString(2, ip);
         pst.setString(3, pc);
         pst.executeUpdate();
         
         stmt = con.createStatement();
         rs = stmt.executeQuery("SELECT * FROM temptablea");
         
         while(rs.next())
         {
             String username = rs.getString(1);
             if(!username.equals(pn))
             {
                 int location_send = rs.getInt(2);
                 boolean isplayed_send = rs.getBoolean(3);
                 String color_send = rs.getString(4);
                 
                 String json = new String(
                           "{ \"Name\":\"" + username + "\"," +
                             "\"Location\":\"" + location_send + "\"," +
                               "\"IsPlayed\":\"" + isplayed_send + "\"," +
                                "\"Color\":\"" + color_send + "\" }"
                 );
                 out.print(json);
             }
         }
         
         
        }
        catch(Exception e)
        {
            out.println("Sorry!! Something went wrong");
            out.println(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

    private ResultSet executeQuery() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
