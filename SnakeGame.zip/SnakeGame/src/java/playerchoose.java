/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

/**
 *
 * @author Rushabh
 */
public class playerchoose extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Connection con = null;
        Statement stmt= null;
        ResultSet rs = null;
        
         String username_input = request.getParameter("opponent");
         String own_username = new String();
         try
        {
            Cookie ck[] = request.getCookies();
            for (Cookie x : ck)
            {
                if(x.getName().equals("UserName")) {
                own_username = x.getValue();
                }
                
            }
            Class.forName("com.mysql.cj.jdbc.Driver");
           
            con= DriverManager.getConnection("jdbc:mysql://localhost:3306/snakeandladder","root","root");
            
            stmt = con.createStatement();
           
            rs=stmt.executeQuery("select * from registrationdata1");
           
            if(username_input != null && own_username != null)
            {
                
                while(rs.next())
                  {
                
                     String username_database = rs.getString(1);
                     
                
                      if(username_database.equals(username_input))
                        {
                            
                            String user_status = rs.getString(3);
                            if(user_status.equals("online"))
                            {
                                
                               stmt.executeUpdate("TRUNCATE TABLE temptablea");
                               stmt.executeUpdate("INSERT INTO temptablea (`Name`, Location, CanPlay, Color) VALUES (\""+own_username+"\", 1, \"true\", \"Red\")");
                               stmt.executeUpdate("INSERT INTO temptablea (`Name`, Location, CanPlay, Color) VALUES (\""+username_input+"\", 1, \"false\", \"Blue\")");
                               stmt.executeUpdate("UPDATE registrationdata1 SET Status=\"playing\" where `Name`=\""+ own_username + "\"");
                               stmt.executeUpdate("UPDATE registrationdata1 SET Status=\"playing\" where `Name`=\""+ username_input + "\"");
                               
                               rs.close();
                               response.sendRedirect("./chooseplayer.html");
                               
                            }
                        }
                  }
         
                //response.sendRedirect("./login2.html");
            }
            else
            {
                response.sendRedirect("./login2.html");
            }
        }
            
         
        catch(Exception e)
        {
            out.println("Sorry!! Something went wrong");
            out.println(e);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
