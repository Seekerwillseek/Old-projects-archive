import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class servletforgame extends HttpServlet {

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
//       
    }

 
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        
        PrintWriter out = response.getWriter();
        Connection con = null;
        Statement stmt= null;
        String n=request.getParameter("username");
        String p=request.getParameter("passw");
        String s= "offline";
        String tt="none";
        try
        {
        
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/snakeandladder","root","root");
           
            stmt = con.createStatement();
            
            stmt.executeUpdate("insert into registrationdata1(Name,Password,Status,tablecol) values('"+n+"','"+p+"','"+s+"','"+tt+"')");
           
            response.sendRedirect("./login.html");
           
            String sql = "select * from registrationdata1 where Name = username1 and Password = passw1";
            
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, "username1");
            
            ps.setString(2, "passw1");

            ResultSet rs = ps.executeQuery();

            if(rs.next())
            {
                response.sendRedirect("./chooseplayer.html");
                
                System.out.println("login successful");
      
             }
            else 
            {
                System.out.println("Incorrect !!");
            }
            }
           
        catch(Exception e)
        {
            out.println("Sorry!! Something went wrong");
            out.println(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

    private ResultSet executeQuery() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
