

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class servletforgame2 extends HttpServlet {

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
//       
    }

 
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        
        PrintWriter out = response.getWriter();
        Connection con = null;
        Statement stmt= null;
        ResultSet rs = null;
       
        int count=0;
        
        String n2=request.getParameter("username1");
        String p2=request.getParameter("passw1"); 
 
        try
        {
          
            Class.forName("com.mysql.cj.jdbc.Driver");
           
            con= DriverManager.getConnection("jdbc:mysql://localhost:3306/snakeandladder","root","root");
            
            stmt = con.createStatement();
           
            rs=stmt.executeQuery("select * from registrationdata1");
           
            if(n2 != null && p2 != null)
            {
                while(rs.next())
                  {
                
                     String un=rs.getString(1);
                     String up=rs.getString(2);
                     
                
                      if(n2.equals(un)&&p2.equals(up))
                        {
                           stmt.executeUpdate("UPDATE registrationdata1 SET Status = \"online\" where `Name`=\""+ un + "\"");
                           Cookie ck = new Cookie("UserName", un);
                           response.addCookie(ck);
                           response.sendRedirect("./chooseplayer.html");
                  
                         //  break;
                        }
                      
                  }
         
                //response.sendRedirect("./login2.html");
            }
            
                
                response.sendRedirect("./login2.html");
            
        }
            
         
        catch(Exception e)
        {
            out.println("Sorry!! Something went wrong");
            out.println(e);
        }
       
      
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
        
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

    private ResultSet executeQuery() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
